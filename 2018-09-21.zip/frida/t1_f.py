from __future__ import print_function
import frida
import sys

def on_message(message, data):
    print(message)

def hook():
    session = frida.attach("t1")
    script = session.create_script("""
    Interceptor.attach(ptr("%s"), {
        onEnter:function(args) {
            send(args[0].toInt32());
        }
    });
    """ % int(sys.argv[1], 16))
    script.on("message", on_message)
    script.load()
    sys.stdin.read()

def modify():
    session = frida.attach("t1")
    script = session.create_script("""
    Interceptor.attach(ptr("%s"), {
        onEnter:function(args) {
            argv[0] = ptr("m");
            args[0] = ptr("1337");
            
        }
    });""" % int(sys.argv[1], 16))
    script.load()
    sys.stdin.read()
def callNew():
    session = frida.attach("t1")
    script = session.create_script("""
    var f = new NativeFunction(ptr("%s"), 'void', ['int']);
    f(9999);
    f(8888);
    f(7777);""" % int(sys.argv[1], 16))
    script.load()
#hook()
#modify()
callNew()