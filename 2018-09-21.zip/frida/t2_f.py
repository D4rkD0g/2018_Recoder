from __future__ import print_function
import frida
import sys

session = frida.attach("t2")
script = session.create_script("""
var s = Memory.allocUtf8String("Lambda!");
var f = new NativeFunction(ptr("%s"), 'int', ['pointer']);
f(s);
""" % int(sys.argv[1], 16))
def on_message(message, data):
    print(message)
script.on('message', on_message)
script.load()