//
//  libInject.h
//  libInject
//
//  Created by Sirius on 2018/9/25.
//  Copyright © 2018 Sirius. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface libInject : NSObject

@end
