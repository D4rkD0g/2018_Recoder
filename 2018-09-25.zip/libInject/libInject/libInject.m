//
//  libInject.m
//  libInject
//
//  Created by Sirius on 2018/9/25.
//  Copyright © 2018 Sirius. All rights reserved.
//

#import "libInject.h"

@implementation libInject

__attribute__((constructor)) void myentry() {
    NSLog(@"Injected successfully!!!");
}

@end
